# June Bug

Start Time: 10/08/2023
Plan: Cancelled
Location: BRK
Dock: G
Boat Type: Sail Mono
Length: 24
Email: kbochat@hotmail.com
Monthly Revenue: 0
First Name: Ken
Last Name: Bochat
Start: 6
Interval: 2
Billing: Sailor Skills
Payment Processor: Stripe

[Junebug Service Log](Junebug%20Service%20Log%20eff089347eac4b779e71cc5762998562.md)

[Junebug Service ](Junebug%20Service%20ac0febc7c48d459ea9be355c51539f45.csv)