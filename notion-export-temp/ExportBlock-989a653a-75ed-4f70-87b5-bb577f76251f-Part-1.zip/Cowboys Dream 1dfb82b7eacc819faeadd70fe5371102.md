# Cowboys Dream

Start Time: 06/04/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: K
Slip #: 129
Boat Type: Power
Make: Hatteras
Length: 50
Email: armanjsyed@gmail.com
Phone: 5102607204
Base Rate: $6.00
Props: 2
Hulls: 1
First Name: Arman
Last Name: Syed
Start: 6
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Cowboy’s Dream Service Log](Cowboys%20Dream%20Service%20Log%201e5b82b7eacc80caa6dce62695747ffc.md)

[Cowboys Dream Conditions](Cowboys%20Dream%20Conditions%201e5b82b7eacc81b89133fd77ad3429d3.csv)

[Cowboys Dream Admin](Cowboys%20Dream%20Admin%201e5b82b7eacc80e39797c6c96cb5ca21.csv)

[Cowboys Dream Service Log](Cowboys%20Dream%20Service%20Log%201e5b82b7eacc80caa6dce62695747ffc.md)