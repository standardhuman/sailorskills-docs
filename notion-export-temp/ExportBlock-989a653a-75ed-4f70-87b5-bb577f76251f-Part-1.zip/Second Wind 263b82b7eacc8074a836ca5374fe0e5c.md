# Second Wind

Start Time: 11/06/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 417
Boat Type: Sail Mono
Make: Capri
Length: 25
Email: sharongreenhagen@gmail.com
Base Rate: $4.50
Monthly Revenue: 112.5
Props: 0
Hulls: 1
First Name: Sharon
Last Name: Greenhagen
Start: 9
Interval: 1
Billing: Zoho
Payment Processor: Stripe

[Second Wind Service Log](Second%20Wind%20Service%20Log%20263b82b7eacc81e8aa85c72252ed15e6.md)

[Second Wind Admin](Second%20Wind%20Admin%20263b82b7eacc818890e5eb4613f5471e.csv)

[Second Wind Conditions](Second%20Wind%20Conditions%20263b82b7eacc81feb4cee66e774f1533.csv)