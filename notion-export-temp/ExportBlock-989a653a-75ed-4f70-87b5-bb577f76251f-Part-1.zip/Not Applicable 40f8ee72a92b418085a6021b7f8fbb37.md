# Not Applicable

Start Time: 11/06/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 236
Boat Type: Sail Mono
Make: Santana
Length: 22
Email: underasail@yahoo.com
Phone: (231) 735-4235
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Max
Last Name: Thompson
Start: 1
Interval: 2
Billing: Zoho
Payment Processor: Stripe

[Not Applicable Service Log](Not%20Applicable%20Service%20Log%20b990676e92454511b5a29f7c6f88c713.md)

[Wicked Conditions (1)](Wicked%20Conditions%20(1)%2047f99fcdb2f74bc39f0a5c445c479e51.csv)

[Wicked Admin](Wicked%20Admin%2024ad9701572a4de681acb0dd75c9a8fd.csv)