# Desiderata

Start Time: 06/17/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: F
Slip #: 300
Boat Type: Sail Mono
Make: Seabird
Length: 37
Email: Josinengland@yahoo.co.uk
Phone: 5103032252
Base Rate: $6.00
Props: 0
Hulls: 1
First Name: Jocelyn
Last Name: Poulin
Start: 6
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Desiderata Service Log](Desiderata%20Service%20Log%20206b82b7eacc81d79db6ee565a967e32.md)

[Desiderata Admin](Desiderata%20Admin%20206b82b7eacc819884b9c3001d537e26.csv)

[Desiderata Conditions](Desiderata%20Conditions%20206b82b7eacc810a8ea5cae4ed4be43e.csv)