# Boondoggle

Start Time: 09/03/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: J
Slip #: 359
Boat Type: Power
Make: Ranger tugs
Length: 30
Email: MCDOUGALL.AH@GMAIL.COM
Phone: 5103752580
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Alex
Last Name: McDougall
Start: 3
Interval: 3
Billing: Zoho
Payment Processor: Zoho

[Boondoggle Service Log](Boondoggle%20Service%20Log%201b6b82b7eacc8046bfd1c78bc5a55341.md)

[Boondoggle Conditions](Boondoggle%20Conditions%201b6b82b7eacc80d0ad68ccda065106f2.csv)

[Boondoggle Admin](Boondoggle%20Admin%201b6b82b7eacc80709d43d3b32efca1c9.csv)