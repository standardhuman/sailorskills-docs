# Voyager

Start Time: 10/01/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 924
Boat Type: Power
Length: 75
Email: info@compassrosecharters.com
Phone: (510) 523-9500
Monthly Revenue: 0
Props: 2
Hulls: 1
First Name: Compass Rose Yacht Charters
Start: 3
Interval: 6
Billing: Zoho
Payment Processor: Zoho

[Voyager Service Log](Voyager%20Service%20Log%2018bb82b7eacc8008bd16eceb5c5b44cd.md)

[Voyager Admin](Voyager%20Admin%2018bb82b7eacc80fc93b2d0825ab81da0.csv)

[Voyager Conditions](Voyager%20Conditions%2018bb82b7eacc814abf09e7c492688880.csv)