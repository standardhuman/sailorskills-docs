# Stargazer

Start Time: 04/01/2024
Plan: Expired
Dock: O
Boat Type: Sail Mono
Email: duevansmd@gmail.com
First Name: Dennis
Last Name: Evans
Start: 4
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

# Services

| Date | Time | Duration | Paint | Growth | Anodes | Thru-hulls | Prop | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 04/15/2023 | **17:59 - 18:25** | 0:26 | Good | Moderate | - | Sound | Good |  |

[Stargazer Service Log](Stargazer%20Service%20Log%20aa8ccd59e41949e681052f332597ee2d.md)