# Beleza

Start Time: 08/10/2025   (PDT) →  
Plan: Paused
Location: BRK
Dock: N
Slip #: 114
Boat Type: Power
Make: Nova Heritage
Length: 40
Email: rsk.nautical@gmail.com
Phone: 19176600775
Monthly Revenue: 0
First Name: Robert
Last Name: Kingston
Start: 2
Interval: 3
Billing: Sailor Skills
Payment Processor: Stripe

[Beleza Service Log](Beleza%20Service%20Log%20e34e73ca7b8043fab0f537f31eadecba.md)

[Beleza Conditions](Beleza%20Conditions%2060a747514f624403ad4d3ed4c6605f7d.csv)

[Beleza Admin](Beleza%20Admin%207d782773f16e41109ddabbd03f8ca0a9.csv)