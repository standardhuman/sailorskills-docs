# Glitch

Start Time: 11/07/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 214
Boat Type: Sail Mono
Make: Express
Length: 27
Email: sam.kronick@gmail.com
Phone: 6125324561
Monthly Revenue: 0
Props: 0
Hulls: 1
First Name: Sam
Last Name: Kronick
Start: 8
Interval: 1
Anodes: MTY-CMX01 (https://www.notion.so/MTY-CMX01-5df8888a543f4247a15e1428af069eeb?pvs=21)
Billing: Sailor Skills
Payment Processor: Stripe

[Glitch Service Log](Glitch%20Service%20Log%2049c4b5e9e6824568a09be34aad2c4e20.md)

[Glitch Conditions](Glitch%20Conditions%20969dfbfacc614c7fba9542ffc708e103.csv)

[Glitch Admin](Glitch%20Admin%20b1e9bba802894e758af0343bbcd4a8b2.csv)