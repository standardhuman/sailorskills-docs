# Bennu

Start Time: 11/05/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: L
Slip #: 216
Boat Type: Sail Mono
Make: Spencer
Length: 35
Email: dylanmeister@gmail.com
Phone: 9255281553
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Dylan
Last Name: Johnston
Start: 1
Interval: 2
Billing: Zoho
Payment Processor: Stripe

[Bennu Service Log](Bennu%20Service%20Log%2042eec4a8ec704df1b10de2b2c52a414d.md)

[Bennu Conditions](Bennu%20Conditions%20969733132a6a495b9abc4bf972fccad4.csv)

[Bennu Admin Bennu](Bennu%20Admin%20Bennu%205253ef3f97a84e7fb7af07f36b5fe552.csv)