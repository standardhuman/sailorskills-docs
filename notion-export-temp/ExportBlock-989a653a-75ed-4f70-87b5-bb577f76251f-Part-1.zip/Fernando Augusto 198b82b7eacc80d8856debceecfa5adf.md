# Fernando Augusto

Start Time: 11/06/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 612
Boat Type: Sail Mono
Make: Catalina
Length: 27
Email: f.h.augusto@gmail.com
Phone: (469)-336-7897
Base Rate: $4.50
Monthly Revenue: 44.55
Props: 1
Hulls: 1
First Name: Fernando
Last Name: Augusto
Start: 2
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Fernando Augusto Service Log](Fernando%20Augusto%20Service%20Log%20198b82b7eacc811baa93cfee947c68a9.md)

[Fernando Augusto Admin](Fernando%20Augusto%20Admin%20198b82b7eacc810bba87c9b4805ee850.csv)

[Fernando Augusto Conditions](Fernando%20Augusto%20Conditions%20198b82b7eacc8153bcbbdb348604e7a8.csv)