# Maiden California

Start Time: 11/08/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 104
Boat Type: Sail Mono
Make: Olson
Length: 30
Email: hawkeye.king@gmail.com
Phone: 9547560264
Monthly Revenue: 0
Props: 0
Hulls: 1
First Name: Hawkeye
Last Name: King
Start: 6
Interval: 1
Billing: Sailor Skills
Payment Processor: Stripe

[Maiden California Service Log](Maiden%20California%20Service%20Log%206573212e37f248f1b81bf2d6da4d72b4.md)

[Maiden California Conditions](Maiden%20California%20Conditions%2060d3cf0f0d97463f9d70736220500d2b.csv)

[Maiden California Admin](Maiden%20California%20Admin%204f36fbc9942040c28040ac10dde19370.csv)