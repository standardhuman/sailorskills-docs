# Smogen 2

Start Time: 11/08/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 520
Boat Type: Sail Mono
Make: Imagine
Length: 36
Email: fulloa@ucsc.edu
Phone: 5102416158
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Felipe
Last Name: Ulloa
Start: 5
Interval: 2
Billing: Zoho
Payment Processor: Stripe

[Smogen 2 Service Log](Smogen%202%20Service%20Log%201661330c838c4064978fb6302574202b.md)

[Smogen 2 Conditions](Smogen%202%20Conditions%209b7a0f19503d4601bcf2e08c053fad3c.csv)

[Smogen 2 Services](Smogen%202%20Services%20fda365159ba64e44bb1d8d02cca2eb79.csv)