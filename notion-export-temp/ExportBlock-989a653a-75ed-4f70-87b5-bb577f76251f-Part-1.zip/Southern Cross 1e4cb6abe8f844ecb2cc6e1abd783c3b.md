# Southern Cross

Start Time: 11/09/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: I
Slip #: 17
Boat Type: Sail Mono
Make: Catalina
Length: 42
Email: mzigler@mac.com
Phone: 4156091143
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Mike
Last Name: Zigler
Start: 1
Interval: 2
Anodes: CAMP X-4 (https://www.notion.so/CAMP-X-4-04238caa1b7c4edfae397001d4a2b136?pvs=21), R-3 (https://www.notion.so/R-3-59908018beee4c8c926c9d5b52459817?pvs=21)
Billing: Sailor Skills
Payment Processor: Stripe

[Southern Cross Service Log](Southern%20Cross%20Service%20Log%20d778d943dc14457a8cf8c4b632488af5.md)

[Southern Cross Conditions](Southern%20Cross%20Conditions%2039c1e3262f714f76b2ab920f10179030.csv)

[Southern Cross Admin](Southern%20Cross%20Admin%2071dcf4c74b5c450093af2a5392b8ed1f.csv)