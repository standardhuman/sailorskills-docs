# Joyous Spirit

Start Time: 10/15/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 3
Boat Type: Sail Mono
Make: Newport
Length: 20
Email: samfcurran@gmail.com
Phone: 6038410979
Monthly Revenue: 0
Props: 0
Hulls: 1
First Name: Samuel
Last Name: Curran
Start: 2
Interval: 2
Billing: Zoho
Payment Processor: Stripe

[Joyous Spirit Service Log](Joyous%20Spirit%20Service%20Log%20d69be1d17b5047cbb0da761c02e677de.md)

[Joyous Spirit Conditions](Joyous%20Spirit%20Conditions%200d9bba1467094c028736cebd619824b4.csv)

[Joyous Spirit Admin](Joyous%20Spirit%20Admin%204920e7d6e47841f79128f90d446e6073.csv)