# Persephone

Start Time: 03/06/2025   (PST) →  
Plan: Expired
Location: BRK
Dock: Z
Slip #: 2
Boat Type: Sail Mono
Make: Cal Jensen
Length: 39
Email: bill.rus@gmail.com
Phone: 415-419-4675
First Name: Bill
Last Name: Rus
Start: 3
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Persephone Service Log](Persephone%20Service%20Log%20127b82b7eacc8193b333f10dd14801d3.md)

[Persephone Conditions](Persephone%20Conditions%20127b82b7eacc8175aad4d2c5b33e4aa8.csv)

[Persephone Admin](Persephone%20Admin%20127b82b7eacc81f7b250eb4a46597587.csv)