# Blue Heeler

Start Time: 07/15/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: F
Slip #: 103
Boat Type: Sail Mono
Make: Herreshoff
Length: 28
Email: chabot.patrick78@gmail.com
Phone:  (434)-989-1752
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Patrick
Last Name: Chabot
Start: 7
Interval: 6
Billing: Zoho
Payment Processor: Stripe

[Blue Heeler Service Log](Blue%20Heeler%20Service%20Log%2022ab82b7eacc815793ebf8187efb0dd7.md)

[Blue Heeler Admin](Blue%20Heeler%20Admin%2022ab82b7eacc819cb17cc0117a13b7a9.csv)

[Blue Heeler Conditions](Blue%20Heeler%20Conditions%2022ab82b7eacc811eab5ece7d0e5fa4bf.csv)