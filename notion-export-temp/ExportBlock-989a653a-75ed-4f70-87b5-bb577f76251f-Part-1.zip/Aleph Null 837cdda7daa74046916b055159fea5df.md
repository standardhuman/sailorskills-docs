# Aleph Null

Start Time: 11/06/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 408
Boat Type: Sail Mono
Make: Freedom
Length: 25
Email: john.c.danielson@gmail.com
Phone: 5103344198
Monthly Revenue: 0
Props: 0
Hulls: 1
First Name: John
Last Name: Danielson
Start: 4
Interval: 1
Billing: Zoho
Payment Processor: Zoho

[Aleph Null Service Log](Aleph%20Null%20Service%20Log%202e44f13735714a1aac9853748cb2458b.md)

[Aleph Null Conditions](Aleph%20Null%20Conditions%20d67541ce5c6f4a888f687206b35c2224.csv)

[Aleph Null Admin](Aleph%20Null%20Admin%205f175d2b7725457eb62a2a3cfb3ebb0c.csv)