# Robin

Start Time: 11/08/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 312
Boat Type: Sail Mono
Make: C&C
Length: 35
Email: matt.aune@gmail.com
Phone: 8017126797
Base Rate: $4.50
Monthly Revenue: 57.75
Props: 1
Hulls: 1
First Name: Matt
Last Name: Aune
Start: 5
Interval: 3
Billing: Sailor Skills
Payment Processor: Zoho

[Robin Service Log](Robin%20Service%20Log%201f6b82b7eacc81b1a0b8faa9bb12674b.md)

[Robin Admin](Robin%20Admin%201f6b82b7eacc811e8123d851fac330ee.csv)

[Robin Conditions](Robin%20Conditions%201f6b82b7eacc8130a9e6f99b5eb7b910.csv)