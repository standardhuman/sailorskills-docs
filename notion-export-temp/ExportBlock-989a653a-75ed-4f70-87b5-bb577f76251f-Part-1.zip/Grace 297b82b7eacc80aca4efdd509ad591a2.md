# Grace

Start Time: 10/27/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: C
Slip #: 36
Boat Type: Sail Mono
Make: Express
Length: 27
Email: proge@berkeley.edu
Phone: (202) 683-7640
Props: 0
Hulls: 1
First Name: Paul
Last Name: Roge
Start: 10
Interval: 0
Billing: Zoho
Payment Processor: Stripe

[Grace Service Log](Grace%20Service%20Log%20297b82b7eacc81de8eb5ef8e9d7f6621.md)

[Grace Conditions](Grace%20Conditions%20297b82b7eacc818b816cf6a2df4ce5dd.csv)

[Grace Admin](Grace%20Admin%20297b82b7eacc81d1bcb4cb74feae0c1b.csv)