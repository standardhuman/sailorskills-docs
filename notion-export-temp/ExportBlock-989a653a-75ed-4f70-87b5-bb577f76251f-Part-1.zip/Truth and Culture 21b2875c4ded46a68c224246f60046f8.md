# Truth and Culture

Start Time: 05/07/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: K
Boat Type: Sail Mono
Length: 55
Email: tanous@mindspring.com
Phone: (503) 887-3690‬
First Name: Joe
Last Name: Tanous
Start: 5
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Truth and Culture Service Log](Truth%20and%20Culture%20Service%20Log%2057e3c43f48154465862704a698728e9e.md)

[Truth and Culture Conditions](Truth%20and%20Culture%20Conditions%20114b82b7eacc80809102ebea0410bde7.csv)

[Truth and Culture Admin](Truth%20and%20Culture%20Admin%20114b82b7eacc806fbc98cb7a216664e3.csv)