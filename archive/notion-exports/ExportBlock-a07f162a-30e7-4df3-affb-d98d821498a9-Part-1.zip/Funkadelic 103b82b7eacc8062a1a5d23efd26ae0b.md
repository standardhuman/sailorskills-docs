# Funkadelic

Start Time: 04/15/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: H
Slip #: 1
Boat Type: Sail Mono
Length: 43
Email: Justinkommit@gmail.com
Phone: ‪+506 7130 8049‬
First Name: Justin
Last Name: Lujambio
Start: 4
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Funkadelic Service Log](Funkadelic%20Service%20Log%207126e18c54974b77a8db3d442b7fc4ae.md)

[Funkadelic Conditions](Funkadelic%20Conditions%2010e8e477c6814b3f99df4183e053b93d.csv)

[Funkadelic Admin](Funkadelic%20Admin%205e62eb6f10d042f7aec1e95740b3b76f.csv)