# Psycho Tiller

Start Time: 11/05/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: L
Slip #: 116
Boat Type: Power
Make: Jeanneau
Length: 32
Email: hollanderjesse@gmail.com
Phone: (415)-497-0795
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Jesse
Last Name: Hollander
Start: 5
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Psycho Tiller Service Log](Psycho%20Tiller%20Service%20Log%20559ee5ec9f8b4032aa4936fc3ebb6ad9.md)

[Psycho Tiller Conditions](Psycho%20Tiller%20Conditions%2086ccadf05b0e43d6a69ce4c06e5010e4.csv)

[Psycho Tiller Admin](Psycho%20Tiller%20Admin%2095b42bdbd8454d8ea6ab96ea5c8d4d52.csv)