# Moon Lady

Start Time: 07/03/2023
Plan: Cancelled
Location: BRK
Dock: M
Slip #: 139
Boat Type: Sail Mono
Make: Newport
Length: 27
Email: vanessamiller@yahoo.com
Phone: 510-706-8973
Monthly Revenue: 0
First Name: Vanessa
Last Name: Miller
Start: 5
Interval: 2
Billing: Sailor Skills
Payment Processor: Stripe

[Moon Lady Service Log](Moon%20Lady%20Service%20Log%20585d3754a8a24e6f918c775abc3c395e.md)

[Untitled](Untitled%2023448f18eb4341eb8aa2f75204f520a1.csv)