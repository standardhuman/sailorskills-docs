# Freja

Start Time: 11/05/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 506
Boat Type: Sail Mono
Make: Tayana
Length: 37
Email: write.erikj@gmail.com
Phone: 4026901245
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Erik
Last Name: Jensen
Start: 2
Interval: 2
Anodes: MTY-CMC07 (https://www.notion.so/MTY-CMC07-b5a649616162449b9391ecf9ca1fbd87?pvs=21)
Billing: Zoho
Payment Processor: Stripe

[Freja Service Log](Freja%20Service%20Log%20b4e460271e9847d886b517b60d4135ac.md)

9/16 socket and wrench for rudder anodes Martyr ZHC-2

[Freja Conditions](Freja%20Conditions%20bd30eca2cf214b00b55d1267ee2a4c71.csv)

[Services (1)](Services%20(1)%2009a919597fe743cba4c56e3fd55f71de.csv)