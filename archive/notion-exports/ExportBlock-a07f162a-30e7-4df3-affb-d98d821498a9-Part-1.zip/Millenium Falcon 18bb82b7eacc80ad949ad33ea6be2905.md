# Millenium Falcon

Start Time: 08/12/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: O
Slip #: 803
Boat Type: Sail Mono
Make: Columbia
Length: 28
Email: Lsoyarslan@gmail.com
Phone: (510) 501-0792‬
Base Rate: $4.50
Props: 1
Hulls: 1
First Name: Lavent
Last Name: Soyarslan
Start: 2
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Millenium Falcon Service Log](Millenium%20Falcon%20Service%20Log%2018bb82b7eacc812bb509f5dea39529c3.md)

[Columbia 28 Conditions](Columbia%2028%20Conditions%2018bb82b7eacc81c0bc14ea564c6f5f49.csv)

[Millenium Falcon Admin](Millenium%20Falcon%20Admin%2018bb82b7eacc81da828cd81fc40a0fbe.csv)