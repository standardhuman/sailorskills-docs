# Esprit de Moitessier

Start Time: 05/15/2025
Plan: Expired
Location: BRK
Dock: Y
Slip #: 1
Boat Type: Sail Mono
Make: Custom
Length: 28
Email: info@berkeleymarine.com
Base Rate: $6.00
Props: 0
Hulls: 1
First Name: Berkeley
Last Name: Marine Center
Start: 5
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Esprit de Moitessier Service Log](Esprit%20de%20Moitessier%20Service%20Log%20200b82b7eacc818fa366e28f48451f5b.md)

[Esprit de Moitessier Conditions](Esprit%20de%20Moitessier%20Conditions%20200b82b7eacc819c9899d2d198de54d0.csv)

[Esprit de Moitessier Admin](Esprit%20de%20Moitessier%20Admin%20200b82b7eacc810b981cf377dcefe266.csv)