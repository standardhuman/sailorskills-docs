# Yakamoz

Start Time: 09/25/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: G
Slip #: 417
Boat Type: Sail Mono
Make: Columbia
Length: 35
Email: moegev@gmail.com
Phone: 14159908116
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Morris
Last Name: Gevirtz
Start: 3
Interval: 3
Anodes: MTY-CMX01 (https://www.notion.so/MTY-CMX01-5df8888a543f4247a15e1428af069eeb?pvs=21)
Billing: Zoho
Payment Processor: Stripe

[Yakamoz Service Log](Yakamoz%20Service%20Log%204b2ec8cc57c34c2ab152dd9ceef8e2db.md)

[Yakamoz Conditions](Yakamoz%20Conditions%20f99becf384ba4ea39ff08dad7c0f584b.csv)

[Yakamoz Admin](Yakamoz%20Admin%200e17c051c73747409ea2675f20725f47.csv)