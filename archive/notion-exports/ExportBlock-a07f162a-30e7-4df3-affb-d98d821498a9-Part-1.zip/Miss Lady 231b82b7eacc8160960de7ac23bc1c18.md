# Miss Lady

Start Time: 07/15/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: J
Slip #: 113
Boat Type: Sail Mono
Make: Cat
Length: 22
Email: rhodeislandreds@gmail.com
Phone: 7185027891
Props: 0
Hulls: 1
First Name: Christopher
Last Name: Brophy
Start: 7
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Miss Lady Service Log](Miss%20Lady%20Service%20Log%20233b82b7eacc80f8baf3f1bfbd328d7f.md)

[Miss Lady Admin](Miss%20Lady%20Admin%20233b82b7eacc805495a6f67802e4669a.csv)