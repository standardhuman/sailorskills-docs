# China Rose

Start Time: 11/05/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: H
Slip #: 40
Boat Type: Sail Mono
Make: Ingrid
Length: 38
Email: dianewalton9@earthlink.net
Phone: 4152446264
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Diane
Last Name: Walton
Start: 1
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[China Rose Service Log](China%20Rose%20Service%20Log%20d721c77eff5540da9b4a8d2d537d8844.md)

[China Rose Conditions](China%20Rose%20Conditions%20960c3cfb16c341c8ae09e9f7b3bc8ad4.csv)

[China Rose Admin](China%20Rose%20Admin%209a4ae8483b4d4c27a7041d37850841ab.csv)