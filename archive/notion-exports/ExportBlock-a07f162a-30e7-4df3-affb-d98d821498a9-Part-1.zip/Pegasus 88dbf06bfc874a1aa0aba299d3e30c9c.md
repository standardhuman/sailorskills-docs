# Pegasus

Start Time: 09/30/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: K
Slip #: 128
Boat Type: Sail Mono
Make: Alden
Length: 51
Email: info@pegasusvoyages.com
Phone: 415-500-5468
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Pegasus
Last Name: Voyages
Start: 9
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Pegasus Service Log](Pegasus%20Service%20Log%20e42e9bbd0d6549efacc6839843d331f5.md)

[Pegasus Conditions](Pegasus%20Conditions%206cd1d23d3dea4782a614914094626f0f.csv)

[Pegasus Admin](Pegasus%20Admin%205958ce4073f64541b6b607f54142b2de.csv)