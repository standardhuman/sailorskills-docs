# Amaterasu

Start Time: 09/30/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: K
Slip #: 135
Boat Type: Power
Make: Coastal Cruiser
Length: 42
Email: raeofshan@gmail.com
Phone: ‭+1 (415) 741-6726‬
Base Rate: $4.50
Monthly Revenue: 91.35
Props: 2
Hulls: 1
First Name: Shannon
Last Name: Scott
Start: 9
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Amaterasu Service Log](Amaterasu%20Service%20Log%20277b82b7eacc81c9a872c95eba719c96.md)

[Amaterasu Admin](Amaterasu%20Admin%20277b82b7eacc81829fecfc779eb7bed7.csv)

[Amaterasu Conditions](Amaterasu%20Conditions%20277b82b7eacc81079a1bd5a1c3a9571c.csv)