# Shirley Jean

Start Time: 06/17/2025   (PDT) →  
Plan: Expired
Location: BRK
Boat Type: Sail Mono
Email: schuerg.timo@gmail.com
Phone: 510-502-6980
Monthly Revenue: 0
First Name: Timo
Last Name: Schuerg
Start: 6
Interval: 6
Billing: Sailor Skills
Payment Processor: Stripe

[Shirley Jean Service Log](Shirley%20Jean%20Service%20Log%20145b82b7eacc81af9de8d5039f868a83.md)

[Shirley Jean Conditions](Shirley%20Jean%20Conditions%20145b82b7eacc81568e53c3f7c6b7f1aa.csv)

[Shirley Jean Admin](Shirley%20Jean%20Admin%20145b82b7eacc814488b7e69d4ba24342.csv)