# Bee Mused

Start Time: 09/22/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: M
Slip #: 135
Boat Type: Sail Mono
Make: Ericson
Length: 27
Email: whirled.peaze@gmail.com
Phone: 510-690-7442‬
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Jeanne
Last Name: LaDeaux
Start: 9
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Bee Mused Service Log](Bee%20Mused%20Service%20Log%20120b82b7eacc8107ae4bf12b2492e7de.md)

[Bee Mused Conditions](Bee%20Mused%20Conditions%20120b82b7eacc81c48c77ead33ac4beb1.csv)

[Bee Mused Admin](Bee%20Mused%20Admin%20120b82b7eacc8132bf74f78790b42155.csv)