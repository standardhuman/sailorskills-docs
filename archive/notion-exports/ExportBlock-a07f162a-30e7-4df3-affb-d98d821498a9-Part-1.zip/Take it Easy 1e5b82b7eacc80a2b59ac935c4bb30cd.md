# Take it Easy

Start Time: 11/05/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: F
Slip #: 211
Boat Type: Power
Make: Sea Ray
Length: 35
Phone: ‪+1 (510) 938‑1646‬
Base Rate: $6.00
Monthly Revenue: 101.5
Props: 2
Hulls: 1
First Name: Jose
Last Name: Larrain
Start: 8
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Take it Easy Service Log](Take%20it%20Easy%20Service%20Log%201e5b82b7eacc813892b2ffe9c6313dbc.md)

[Take it Easy Admin](Take%20it%20Easy%20Admin%201e5b82b7eacc8158b9edf04fa80c0a2f.csv)

[Take it Easy Conditions](Take%20it%20Easy%20Conditions%201e5b82b7eacc81ce9c13f746be988fcf.csv)