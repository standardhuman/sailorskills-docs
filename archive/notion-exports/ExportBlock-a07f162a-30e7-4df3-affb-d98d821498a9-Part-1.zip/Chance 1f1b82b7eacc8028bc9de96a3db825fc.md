# Chance

Start Time: 05/15/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: O
Slip #: 116
Boat Type: Sail Mono
Make: Bear
Length: 23
Email: samgawthrop@gmail.com
Phone: (510)-274-1337
Base Rate: $6.00
Props: 0
Hulls: 1
First Name: Sam
Last Name: Gawthrop
Start: 5
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Chance Service Log](Chance%20Service%20Log%201f1b82b7eacc81e69ddce60d0e7476f7.md)

[Chance Admin](Chance%20Admin%201f1b82b7eacc819d9fe2dac0edc5c2b7.csv)

[Chance Conditions](Chance%20Conditions%201f1b82b7eacc819092fac65680c36922.csv)