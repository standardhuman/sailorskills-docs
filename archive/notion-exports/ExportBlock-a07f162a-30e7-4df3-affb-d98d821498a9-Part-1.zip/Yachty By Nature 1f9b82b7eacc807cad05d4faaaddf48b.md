# Yachty By Nature

Start Time: 10/03/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: O
Boat Type: Power
Length: 68
Email: mwhurst@gmail.com
Base Rate: $4.50
Monthly Revenue: 147.9
Props: 2
Hulls: 1
First Name: Mike
Last Name: Hurst
Start: 6
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Yachty By Nature Service Log](Yachty%20By%20Nature%20Service%20Log%201f9b82b7eacc81578cb2dde2f217c8a2.md)

[Yachty By Nature Admin](Yachty%20By%20Nature%20Admin%201f9b82b7eacc812fb99cfc916e77063f.csv)

[Yachty By Nature Conditions](Yachty%20By%20Nature%20Conditions%201f9b82b7eacc81c4a7d8e0313bc2bc08.csv)