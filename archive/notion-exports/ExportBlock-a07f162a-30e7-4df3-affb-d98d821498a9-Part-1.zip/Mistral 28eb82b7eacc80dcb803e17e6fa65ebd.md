# Mistral

Start Time: 10/15/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: N
Slip #: 106
Boat Type: Sail Mono
Make: Cheoy Lee
Length: 40
Email: tcolton@berkeley.edu
Phone: (510)-847-5771
Base Rate: $4.50
Monthly Revenue: 66
Props: 1
Hulls: 1
First Name: Thomas
Last Name: Colton
Start: 10
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Mistral Service Log](Mistral%20Service%20Log%2028eb82b7eacc8118820ec078c5e1bac6.md)

[Pineapple Express Admin](Pineapple%20Express%20Admin%2028eb82b7eacc81bb8d93d8c4a6808ca4.csv)

[Mistral Conditions](Mistral%20Conditions%2028eb82b7eacc81b69cb0c4e554c979b3.csv)