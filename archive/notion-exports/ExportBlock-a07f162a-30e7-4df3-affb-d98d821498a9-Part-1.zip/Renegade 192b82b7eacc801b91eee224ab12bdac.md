# Renegade

Start Time: 08/11/2025   (PDT) →  
Plan: Expired
Location: BRK
Dock: O
Slip #: 17
Boat Type: Sail Mono
Make: Bear
Length: 23
Email: hhansen@me.com
Phone: (415)-487-8676
Base Rate: $4.50
Props: 0
Hulls: 1
First Name: Hans
Last Name: Hansen
Start: 8
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Renegade Service Log](Renegade%20Service%20Log%20192b82b7eacc81b79ea7cdb95c9f474c.md)

[Renegade Admin](Renegade%20Admin%20192b82b7eacc818f8c76c363e891265c.csv)

[Renegade Conditions](Renegade%20Conditions%20192b82b7eacc81988870e03b2a335ddd.csv)