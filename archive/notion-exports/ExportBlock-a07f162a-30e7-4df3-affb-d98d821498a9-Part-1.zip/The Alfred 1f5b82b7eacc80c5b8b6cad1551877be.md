# The Alfred

Start Time: 06/05/2025   (PDT) →  
Plan: Cancelled
Location: EV COVE
Dock: C
Slip #: 18
Boat Type: Power
Make: Bayliner
Length: 28
Email: beyondimagegrp@yahoo.com
Base Rate: $6.00
Monthly Revenue: 35
Props: 0
Hulls: 1
First Name: Michelle
Last Name: Prior Alameda
Start: 6
Interval: 6
Billing: Sailor Skills
Payment Processor: Stripe

[The Alfred Service Log](The%20Alfred%20Service%20Log%201f5b82b7eacc81758e15e1b6371eb547.md)

[The Alfred Admin](The%20Alfred%20Admin%201f5b82b7eacc81148e47f26ff1cbddf1.csv)

[The Alfred Conditions](The%20Alfred%20Conditions%201f5b82b7eacc81cd9e1de35d00ddaa48.csv)