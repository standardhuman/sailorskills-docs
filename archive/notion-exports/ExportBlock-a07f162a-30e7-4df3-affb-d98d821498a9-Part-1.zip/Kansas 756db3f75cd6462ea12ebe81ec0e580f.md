# Kansas

Start Time: 10/01/2023
Plan: Expired
Location: BRK
Dock: O
Slip #: 615
Boat Type: Sail Mono
Make: Ericson
Length: 29
Email: zackreidman@gmail.com
Phone: 5108511621
First Name: Zach
Last Name: Reidman
Start: 10
Interval: 0
Billing: Sailor Skills
Payment Processor: Stripe

[Kansas Service Log](Kansas%20Service%20Log%202b5c36aa69524a7e8550bfe134daceca.md)

[Kansas Services ](Kansas%20Services%2052745b345a5748da8ea60d4ae475f660.csv)