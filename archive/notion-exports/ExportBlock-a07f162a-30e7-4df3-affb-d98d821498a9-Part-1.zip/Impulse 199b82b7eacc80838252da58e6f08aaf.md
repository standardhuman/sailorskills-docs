# Impulse

Start Time: 08/06/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 303
Boat Type: Sail Mono
Make: Catalina
Length: 30
Email: tylervasquezwater@gmail.com
Phone:  209-612-1522
Base Rate: $4.50
Monthly Revenue: 24.75
Props: 1
Hulls: 1
First Name: Tyler
Last Name: Vasquez
Start: 2
Interval: 6
Billing: Zoho
Payment Processor: Zoho

[Impulse Service Log](Impulse%20Service%20Log%20199b82b7eacc815c8237ee049f9b9517.md)

[Impulse Conditions](Impulse%20Conditions%20199b82b7eacc817bb197cc9e8c4f8f2d.csv)

[Impulse Admin](Impulse%20Admin%20199b82b7eacc813b8deee5ac8fbdb05c.csv)