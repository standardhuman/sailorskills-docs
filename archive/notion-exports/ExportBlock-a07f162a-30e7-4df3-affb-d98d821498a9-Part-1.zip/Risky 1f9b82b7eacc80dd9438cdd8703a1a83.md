# Risky

Start Time: 10/24/2025   (PDT) →  
Plan: Subbed
Location: BRK
Dock: O
Slip #: 819
Boat Type: Sail Mono
Make: Catalina
Length: 30
Email: jzalstein@gmail.com
Phone: 2146629476
Base Rate: $6.00
Monthly Revenue: 66
Props: 1
Hulls: 1
First Name: Jacqueline
Last Name: Zalstein
Start: 10
Interval: 3
Billing: Zoho
Payment Processor: Stripe

[Risky Service Log](Risky%20Service%20Log%201f9b82b7eacc81bf86defb6b8f482d86.md)

[Risky Conditions](Risky%20Conditions%201f9b82b7eacc8156be4cc4eaa37e1633.csv)

[Risky Admin](Risky%20Admin%201f9b82b7eacc817d90ded73a4b0e6347.csv)