# Pazzo Express

Start Time: 11/14/2025   (PST) →  
Plan: Subbed
Location: BRK
Dock: C
Slip #: 36
Boat Type: Sail Mono
Make: Express
Length: 37
Email: gavin.corn@gmail.com
Phone: (202) 683-7640
Monthly Revenue: 0
Props: 1
Hulls: 1
First Name: Gavin
Last Name: Corn
Start: 9
Interval: 1
Billing: Sailor Skills
Payment Processor: Stripe

[Pazzo Express Service Log](Pazzo%20Express%20Service%20Log%20262b82b7eacc81948080f382061e13de.md)

[Pazzo Express Conditions](Pazzo%20Express%20Conditions%20262b82b7eacc8161a38fe566773ec43c.csv)

[Pazzo Express Admin](Pazzo%20Express%20Admin%20262b82b7eacc814e8a81f3644403d191.csv)